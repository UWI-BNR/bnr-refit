

USING THE PACKAGE LOCALLY

EG.
net from c:\statistics\stata\data\hotn_package

Once pkg and toc are in this folder, can get package listing from within Stata
Help (sthlp) files get copied to Stata ADO folder
Datasets (DTA) and do (DO) files get copied to current directoty

To call do files from help files, they must be available in current directory, so don't move